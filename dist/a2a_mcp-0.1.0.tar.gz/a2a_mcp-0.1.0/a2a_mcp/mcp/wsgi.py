from .server import app

# This is the WSGI entry point for Gunicorn
application = app 