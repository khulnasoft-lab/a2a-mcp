"""
A2A vs MCP Demo - Demonstration of different agent communication patterns
"""

__version__ = "0.1.0" 